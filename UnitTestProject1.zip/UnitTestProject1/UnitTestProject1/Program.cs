﻿using SAP.Middleware.Connector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SAP;
using System.IO;
using System.Data;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using System.Xml.XPath;
using System.Xml;
using System.Configuration;
using Microsoft.VisualBasic;

namespace SAPConnection
{
   

    public class Program
    {

        //   public static string exportPathReport = ConfigurationManager.AppSettings["ReportExportPath"].ToString(); //To create a file and export fetched from table.


        private static string[] GetDataFromSAP(string Destination, string tabletoqurey, List<string> fieldsToRead, string condtionField, string conditionValue, string condtionField2, string conditionValue2)
        {

            //TO ACCESS TABLE
            RfcDestination dest = RfcDestinationManager.GetDestination(Destination);
            RfcRepository repo = dest.Repository;


            IRfcFunction rfcReadTable = repo.CreateFunction("RFC_READ_TABLE");
            rfcReadTable.SetValue("DELIMITER", "|");
            rfcReadTable.SetValue("QUERY_TABLE", tabletoqurey);


            if (conditionValue2 != "DUMMY")
            {
                // <BLOCK OF CODE>

            }
            else if (conditionValue2 != "DUMMY")
            {
                // <BLOCK OF CODE>
            }
            IRfcTable fields = rfcReadTable.GetTable("DUMMY");
            foreach (string str in fieldsToRead)
            {
                fields.Append();
                fields.SetValue("DUMMY", str);
            }
            rfcReadTable.Invoke(dest);
            IRfcTable data = rfcReadTable.GetTable("DATA");
            data.ToString().Split('|').ToString();

            string[] abc = new string[1];

            abc[0] = data.ToString();

            return abc;
        }

        public static List<string[]> ReadCSV()
        {
            // Reading Data from CSV per column wise here.
            List<string[]> a = new List<string[]>();
            return a;
        }

        public static void SAP_DUMMY_ENV()

        {
            RfcConfigParameters parameters = new RfcConfigParameters();

            parameters[RfcConfigParameters.Name] = "DUMMY";
            parameters[RfcConfigParameters.User] = "admin";
            parameters[RfcConfigParameters.Password] = "admin";
            parameters[RfcConfigParameters.Client] = "000"; //THIS IS THE SAP CLIENT
            parameters[RfcConfigParameters.Language] = "EN";
            parameters[RfcConfigParameters.AppServerHost] = "SAPServer.company.com";
            parameters[RfcConfigParameters.SystemNumber] = "xx"; //SAP SYSTEM SERVER NUMBER

            //TO START SAP SESSION CONTEXT
            RfcDestination destination = RfcDestinationManager.GetDestination(parameters);
            RfcSessionManager.BeginContext(destination);

            destination.Ping();
            //  IRfcFunction function = null;

            List<string[]> fields = ReadCSV();
            using (StreamWriter sw = File.AppendText("\\<DUMMY INPUT PATH>\\OUTPUT.csv"))
            {
                sw.WriteLine("COL1" + "," + "," + "COL2");
            }
            foreach (string[] s in fields)
            {
                Console.WriteLine(s[0] + "\t" + s[1]);

                List<string> fields_table1 = new List<string>() { "COLUMN_NAME", "COLUMN_ID" }; //DUMMY VALUES

                List<List<string>> data;

                string[] table1_output = GetDataFromSAP("<ENVIRONMENT>", "<SA_TABLE_TO_READ>", fields_table1, "<COLUMN_NAME>", s[0], "<COLUMN_ID>", s[1]);

                string DUMMY = table1_output[0];

            }
            RfcSessionManager.EndContext(destination);
            destination = null;
        }

        static void Main(string[] args)
        {

            SAP_DUMMY_ENV();

        }
    }
}
