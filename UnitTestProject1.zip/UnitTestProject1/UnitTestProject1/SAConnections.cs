﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SAP.Middleware.Connector;
using SAP;

namespace SAPConnection
{
    class SAPDestinationConfig : IDestinationConfiguration
    {
        public bool ChangeEventsSupported()
        {
            return false;
        }

        public event RfcDestinationManager.ConfigurationChangeHandler ConfigurationChanged;


        //ALTERNATIVE APPROACH TO CONNECT TO SAP
        public RfcConfigParameters GetParameters(string destinationName)
        {

            RfcConfigParameters parms = new RfcConfigParameters();

            //Connection For Quality Env.
            if (destinationName.Equals("Q1"))
            {
                parms.Add(RfcConfigParameters.AppServerHost, "sapcrmservername.company.com");
                parms.Add(RfcConfigParameters.SystemNumber, "dummy");
                parms.Add(RfcConfigParameters.SystemID, "Q1");
                parms.Add(RfcConfigParameters.User, "admin");
                parms.Add(RfcConfigParameters.Password, "admin");
                parms.Add(RfcConfigParameters.Client, "000");
                parms.Add(RfcConfigParameters.Language, "EN");
                parms.Add(RfcConfigParameters.PoolSize, "dummy");
            }

            //Connection For Dev Env.
            if (destinationName.Equals("D1"))
            {
                parms.Add(RfcConfigParameters.AppServerHost, "sapcrmservername.company.com");
                parms.Add(RfcConfigParameters.SystemNumber, "dummy");
                parms.Add(RfcConfigParameters.SystemID, "D1");
                parms.Add(RfcConfigParameters.User, "admin");
                parms.Add(RfcConfigParameters.Password, "admin");
                parms.Add(RfcConfigParameters.Client, "000");
                parms.Add(RfcConfigParameters.Language, "EN");
                parms.Add(RfcConfigParameters.PoolSize, "dummy");
            }
            return parms;

        }
        //ALTERNATIVE APPROACH TO CONNECT TO SAP
        public static RfcRepository getRfcRepo(string destinationName)
        {
            SAPDestinationConfig cfg = new SAPDestinationConfig();
            RfcDestinationManager.RegisterDestinationConfiguration(cfg);
            RfcDestination dest = RfcDestinationManager.GetDestination(destinationName);
            RfcRepository repo = dest.Repository;
            return repo;
        }
    }
}
